 $("#PackageDestination").change(function () {
            var PackageDestination= $("#PackageDestination option:selected").text();
            $.ajax({
                type: 'POST',
                url: 'package/activity',
                data: {"activityv":PackageDestination},
                success: function (res) {
                    if(res!="")
                    {
                        $('#activity1').html(res);
$('#activity1').material_select();

                    } 
                }
            });
        });


 $("#PackageDestination").change(function () {
            var PackageDestination= $("#PackageDestination option:selected").text();
          
            $.ajax({
                type: 'POST',
                url: 'package/city',
                data: {"destination":PackageDestination},
                success: function (res) {
                    if(res!="")
                    {
                        $('#city1').html(res);
$('#city1').material_select();

                    } 
                }
            });
        });
        
        
       /* $("#city").change(function () {
            var City= $("#city option:selected").text();
            $.ajax({
                type: 'POST',
                url: 'package/hotel',
                data: {"city":City},
                success: function (res) {
                    if(res!="")
                    {
                        $('#hotel').html(res);
$('#hotel').material_select();

                    } 
                }
            });
        });
*/

function hotel_list(str) {
    debugger;
            var City= $("#city"+str+" option:selected").text();
            $.ajax({
                type: 'POST',
                url: 'package/hotelbudget',
                data: {"city1":City},
                success: function (res1) {
                    if(res1!="")
                    {
                        $('#hotelb'+str).html(res1);
$('#hotelb'+str).material_select();

                    } 
                }
            });
                        $.ajax({
                type: 'POST',
                url: 'package/hotelstandard',
                data: {"city2":City},
                success: function (res2) {
                    if(res2!="")
                    {
                        $('#hotels'+str).html(res2);
$('#hotels'+str).material_select();

                    } 
                }
            });
                        $.ajax({
                type: 'POST',
                url: 'package/hoteldeluxe',
                data: {"city3":City},
                success: function (res3) {
                    if(res3!="")
                    {
                        $('#hoteld'+str).html(res3);
$('#hoteld'+str).material_select();

                    } 
                }
            });
        }


   function decrypvalue(x)
{

$('#activitydesc'+x).val($('#activity'+x).val());
$('#activitytitle'+x).val($("#activity"+x+" option:selected").html());
}