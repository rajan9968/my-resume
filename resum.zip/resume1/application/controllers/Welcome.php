<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function index()
	{
if(isset($_POST['submit']))
		{
			date_default_timezone_set('Asia/Kolkata');

			$message = '<html><body>';
			$message .= '<table rules="all" style="border-color: #666; border:1px solid #666;" cellpadding="10">';
			$message .= "<tr style='background: #eee;'><td colspan='2'><strong>Website Enquiry</strong> </td></tr>";

			$message .= "<tr><td><strong>Name:</strong> </td><td>" . strip_tags($this->input->post('name')) . "</td></tr>";

			$message .= "<tr><td><strong>Email:</strong> </td><td>" .strip_tags($this->input->post('email')) . "</td></tr>";

			$message .= "<tr><td><strong>Email:</strong> </td><td>" .strip_tags($this->input->post('mobile')) . "</td></tr>";

			$message .= "<tr><td><strong>Email:</strong> </td><td>" .strip_tags($this->input->post('message')) . "</td></tr>";



			$message .= "<tr><td><strong>Email:</strong> </td><td>" .strip_tags($this->input->post('addeddate')) . "</td></tr>";



			$message .= "</table>";
			$message .= "</body></html>";

			$to = 'ra580jan@gmail.com';
			$this->load->library('email');
			$this->email->set_newline("\r\n");
			$this->email->set_mailtype("html");
			$this->email->from('website');
			$this->email->to($to);
			$this->email->subject('Website Enquiry');
			$this->email->message($message);

		 
		 
		 if($this->email->send())
		 {
			 echo '<script>alert("Thanks for Enquiry,Our executive will contact you shortly.")</script>';
			 
			
			 
		 }

		 	date_default_timezone_set('Asia/Kolkata');

			$data['name']=$this->input->post('name');
			$data['email']=$this->input->post('email');
			$data['mobile']=$this->input->post('mobile');
			$data['message']=$this->input->post('message');
			$data['addeddate']= date('y-m-d h:i:sA');
			
			$this->crud->insert('resume1_tbl_contact',$data);
		}

		$this->load->view('index');
	}


}
