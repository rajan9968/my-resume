<?php


class Profile_cate extends CI_Controller
{
	
	function chech_admin_login()
	{
		$ci = & get_instance();
		$USERID      = $ci->session->userdata('USERID');	
		$USERNAME      = $ci->session->userdata('USERNAME');	
		$logged_in      = $ci->session->userdata('logged_in');	
		if($USERID=="" && $USERNAME=="")
		{
			redirect('index.php/admin/index');
		}
		
	}


	function listing()
	{
		$args =func_get_args();
		$data['PROFILEDATA']=$this->crud->get_data('resume1_tbl_categ');
		$this->load->view('admin/profilecate/list',$data);
	}


	function add()
	{
		$this->chech_admin_login();
		if (isset($_POST['submit']))
		 {
			if ($_FILES['image']['name']!='')
			 {
				$bimage =$_FILES['image']['name'];
				$path ='media/uploads/profile/'.$bimage;
				move_uploaded_file($_FILES['image']['tmp_name'],$path);

			}

			else
			{
				$bimage = "";
			}

			$data['image']= $bimage;
			$data['cate_name'] = implode(",",$this->input->post('cate'));

			$this->crud->insert('resume1_tbl_categ',$data);

			$this->session->set_flashdata('message','<div class="alert alert-success">Record has been successfully saved.</div>');
			
			redirect('profile_cate/listing');		


		}

		$this->load->view('admin/profilecate/add');
		
	}


	function edit()
	{
		$this->chech_admin_login();
		$args=func_get_args();

		if (isset($_POST['submit']))
		 {

		 	if ($_FILES['image']['name'])
		 	 {
		 	 	$bimage= $_FILES['image']['name'];
		 	 	$path ='media/uploads/profile/'.$bimage;
		 	 	move_uploaded_file($_FILES['image']['tmp_name'],$path);

		 	 }	

		 	 else
		 	 {
		 	 	$bimage=$_POST['oldimage'];
		 	 }	 	 		
		 				 	



			$data['image']=$bimage;
			$data['cate_name']= implode(",",$this->input->post('cate'));

			$this->crud->update('resume1_tbl_categ',$args[0],$data);


			$this->session->set_flashdata('message','<div class="alert alert-success">Record has been successfully saved.</div>');


			redirect('profile_cate/listing');
			


		}

		$data['EDITDATA']= $this->crud->fetchdatabyid($args[0],'resume1_tbl_categ');
		$this->load->view('admin/profilecate/edit',$data);

	}


function delete()
	{
		$args=func_get_args();
		$this->chech_admin_login();

		$this->crud->selectdatabymulitplewhere('resume1_tbl_categ',array('id'=>$args[0]));
		$path = 'media/uploads/profile'.$data[0]->image;
		@unlink($path);
		$this->crud->delete('resume1_tbl_categ',$args[0]);
		$this->session->set_flashdata('message','<div class="alert alert-success">Record has been successfully saved.</div>');
			
			redirect('profile_cate/listing');
	}

}