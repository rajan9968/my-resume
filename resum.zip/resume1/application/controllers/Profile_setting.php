<?php

class Profile_setting extends CI_Controller
{


    function chech_admin_login()
    {
        $ci = & get_instance();
        $USERID      = $ci->session->userdata('USERID');    
        $USERNAME      = $ci->session->userdata('USERNAME');    
        $logged_in      = $ci->session->userdata('logged_in');  
        if($USERID=="" && $USERNAME=="")
        {
            redirect('index.php/admin/index');
        }
    }

//     function listing()
//     {
//         $this->chech_admin_login();
//         $data['PROFILE']= $this->crud->get_data('tbl_profile')l;
//         $this->load->view('admin/slider/list/',$data);

//     }

    function edit()
    {
            $this->chech_admin_login();
        $args=func_get_args();

        if(isset($_POST['submit']))
        {
            if($_FILES['image']['name']!='')
            {
                $image=$_FILES['image']['name'];
                $path= 'media/uploads/profile/'.$image;
                move_uploaded_file($_FILES['image']['tmp_name'],$path);
            }
            else
            {
                $image =$_POST['oldimage'];
            }
            
            $data['image']= $image;
        $data['name'] =$this->input->post('name');
        $data['email']= $this->input->post('email');
        $data['mobile']= $this->input->post('mobile');
        $data['address']= $this->input->post('address');
        $this->crud->update('resume1_tbl_profile',$args[0],$data);
        

        $this->session->set_flashdata('message','<div class="alert alert-success">Record has been successfully updated.</div>');

        
        }
        $data['EDITDATA']= $this->crud->fetchdatabyid($args[0],'resume1_tbl_profile');
        $this->load->view('admin/profile/edit',$data);

    }


}



