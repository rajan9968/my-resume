<?php

class Contact extends CI_Controller
{
	
	function listing()
    {
    	$this->chech_admin_login();
    	$data['EDITDATA']=$this->crud->get_data('resume1_tbl_contact');
    	$this->load->view('admin/contact/list',$data);
    }


    function chech_admin_login()
    {
    	$ci = & get_instance();
		$USERID      = $ci->session->userdata('USERID');	
		$USERNAME      = $ci->session->userdata('USERNAME');	
		$logged_in      = $ci->session->userdata('logged_in');	
		if($USERID=="" && $USERNAME=="")
		{
			redirect('index.php/admin/index');
		}
    }


    function delete()
    {
    	$args =func_get_args();
    	$data=$this->crud->selectdatabymulitplewhere('resume1_tbl_contact',array('id'=>$args[0]));
    	$this->crud->delete('resume1_tbl_contact',$args[0]);
    	$this->session->set_flashdata('message','<div class="alert alert-success">Record has been successfully deleted.</div>');
		redirect('contact/listing');


    }


}