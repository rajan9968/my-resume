<!DOCTYPE html>
<html lang="en">

 
<head>
    <title></title>
    <!--== META TAGS ==-->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
   

    <!-- GOOGLE FONTS -->
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:400,600,700" rel="stylesheet">

  <!-- FONT-AWESOME ICON CSS -->
     <link rel="stylesheet" href="<?php echo base_url();?>/media/front/css/font-awesome.min.css">

    <!--== ALL CSS FILES ==-->
    <link rel="stylesheet" href="<?php echo base_url();?>/media/admin/css/style.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/media/admin/css/mob.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/media/admin/css/bootstrap.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/media/admin/css/materialize.css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
</head>

<body>
    <div class="blog-login">
        <div class="blog-login-in">
		  <?php echo $this->session->flashdata('message'); ?>
            <form method="post"> 
                <img src="images/logo.png" alt="" />
                <div class="row">
                    <div class="input-field col s12">
                        <input id="first_name1" name="username" type="text" class="validate" placeholder="username">
                       
                    </div>
                </div>
                <div class="row">
                    <div class="input-field col s12">
                        <input id="last_name" type="password" name="password" class="validate" placeholder="password">
                        
                    </div>
                </div>
                <div class="row">
                    <div class="input-field col s12">
					 <button class="waves-effect waves-light btn-large btn-log-in" type="submit" name="submit">Log In</button></span>
                      
                    </div>
                </div>
                <a href="#" class="for-pass">Forgot Password?</a>
            </form>
        </div>
    </div>

    <!--======== SCRIPT FILES =========-->

</body>
 
</html>