<div class="sb2-13">
                    <ul class="collapsible" data-collapsible="accordion" >
                        <li style="margin:35px 0 0 0;"><a href="<?php echo base_url('admin/dashboard');?>" class="menu-active"><i class="fa fa-bar-chart" aria-hidden="true"></i> Dashboard</a>
                        </li>
                         
                           <li><a href="javascript:void(0)" class="collapsible-header"><i class="fa fa-umbrella" aria-hidden="true"></i>Profile</a>
                            <div class="collapsible-body left-sub-menu">
                                <ul>
                                  
 <li><a href="<?php echo base_url('Profile_setting/edit/1');?>">Edit Profile</a>
                                    </li>
                                    
                                   
                                   
                                </ul>
                            </div>
                        </li>


                           <li><a href="javascript:void(0)" class="collapsible-header"><i class="fa fa-umbrella" aria-hidden="true"></i>Profile Cate</a>
                            <div class="collapsible-body left-sub-menu">
                                <ul>
                                  
 <li><a href="<?php echo base_url('Profile_cate/listing');?>">All Profile Categ</a>
    <li><a href="<?php echo base_url('Profile_cate/add');?>">Add Profile Categ</a>
                                    </li>
                                    
                                   
                                   
                                </ul>
                            </div>
                        </li>
                         
                         
                       
                            
                        </li>

                         <li><a href="<?php echo base_url('contact/listing');?>" class="collapsible-header"><i class="fa fa-umbrella" aria-hidden="true"></i> Contact </a>
                            
                        </li>
					 
					 
                    </ul>
                </div>