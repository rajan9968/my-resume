     <script src="<?php echo base_url();?>media/admin/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>media/admin/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>media/admin/js/materialize.min.js"></script>
    <script src="<?php echo base_url();?>media/admin/js/custom.js"></script>
	<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js" ></script>
 
<script>
function getUrl(inputtext)
{
	var inputVal = inputtext.trim().replace(/[^a-z0-9]+/gi,'-').toLowerCase();
	$('#urlkey').val(inputVal);
}
</script>