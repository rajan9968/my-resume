<!DOCTYPE html>
<html>
<head>
	<title></title>
    <!--== META TAGS ==-->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!--== FAV ICON ==-->
    <link rel="shortcut icon" href="<?php echo base_url();?>/media/admin/images/fav.ico">

    <!-- GOOGLE FONTS -->
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:400,600,700" rel="stylesheet">

    <!-- FONT-AWESOME ICON CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>/media/admin/css/font-awesome.min.css">

    <!--== ALL CSS FILES ==-->
    <link rel="stylesheet" href="<?php echo base_url();?>/media/admin/css/style.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/media/admin/css/mob.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/media/admin/css/bootstrap.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/media/admin/css/materialize.css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
	<script type="text/javascript" src="<?php echo base_url(); ?>media/admin/tiny_mce/tiny_mce.js"></script>
	<script type="text/javascript">
tiny();
	function tiny()
{
tinyMCE.init({
		// General options
		mode : "textareas",
		theme : "advanced",
		skin : "o2k7",
		forced_root_block : "",
        //skin_variant : "black",
		plugins : "openmanager,autolink,lists,pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,nonbreaking,xhtmlxtras,template,wordcount,advlist,autosave,visualblocks",

		// Theme options
		theme_advanced_buttons1 : "save,newdocument,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,styleselect,formatselect,fontselect,fontsizeselect",
		theme_advanced_buttons2 : "cut,copy,paste,pastetext,pasteword,|,search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
		theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,iespell,media,advhr,|,print,|,ltr,rtl,|,fullscreen",
		theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,pagebreak,restoredraft,visualblocks,|,openmanager",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_statusbar_location : "bottom",
		theme_advanced_resizing : true,
		
		//Open Manager Options
		file_browser_callback: "openmanager",
		open_manager_upload_path: '../../../../uploads/',

		// Example content CSS (should be your site CSS)
		content_css : "css/content.css",

		// Drop lists for link/image/media/template dialogs
		template_external_list_url : "lists/template_list.js",
		external_link_list_url : "lists/link_list.js",
		external_image_list_url : "lists/image_list.js",
		media_external_list_url : "lists/media_list.js",

		// Style formats
		style_formats : [
			{title : 'Bold text', inline : 'b'},
			{title : 'Red text', inline : 'span', styles : {color : '#ff0000'}},
			{title : 'Red header', block : 'h1', styles : {color : '#ff0000'}},
			{title : 'Example 1', inline : 'span', classes : 'example1'},
			{title : 'Example 2', inline : 'span', classes : 'example2'},
			{title : 'Table styles'},
			{title : 'Table row 1', selector : 'tr', classes : 'tablerow1'}
		],

		// Replace values for the template plugin
		template_replace_values : {
			username : "Some User",
			staffid : "991234"
		}
	});
}

</script>
</head>
<body>
	<!--== MAIN CONTRAINER ==-->
        <?php $this->view('admin/layout/header');?>

    <!--== BODY CONTNAINER ==-->

    <div class="container-fluid sb2">
    	<div class="row">
    		<div class="sb2-1">
    			                 
                <!--== LEFT MENU ==-->
                  <?php $this->view('admin/layout/left-menu');?>
    		</div>

    		<div class="sb2-2">
    			<div class="sb2-2-2">
    				<ul>
    					<li>
    						<a href="#"><i class="fa fa-home" aria-hidden="true"></i> Home</a>
    					</li>
    					<li class="active-bre"><a href="#">Edit Slider</a></li>
    				</ul>
    			</div>

      <div class="sb2-2-add-blog sb2-2-1">
            <form method="post" enctype="multipart/form-data">
              <div class="row">
                
                <div class="control-group">
                  <label class="control-label">Old Image <font color="#FF0000">* </font></label>
                  <div class="controls">
                    <img src="<?php echo base_url(); ?>/media/uploads/profile/<?php echo $EDITDATA[0]->image; ?>" width="90" height="50"/>
                    <input type="hidden" name="oldimage" value="<?php echo $EDITDATA[0]->image; ?>" />
                    </div>
                </div>

                <div class="input-field col s12">
                  <div class="file-field" style="margin:20px 0 0 0;">
                    <div class="btn">
                      <span>Image</span>
                      <input type="file" name="image">
                    </div>
                    <div class="file-path-wrapper">
                      <input class="file-path validate" type="text" placeholder="Upload Slider Image (Image Size Should be 792 x 535)">
                    </div>
                  </div>
                </div>

                <div class="input-field col s12">
              
            
              
                  <select name="cate[]" multiple>
                    <option>Select Categ</option>

                      <?php 
                      $data1=$this->crud->get_data('profile_cate');
                      foreach($data1 as $data)
                      { 
            
            $module=explode(",",$EDITDATA[0]->cate_name);
                      $countmodule=count($module);
            
            
            
                      for($m=0;$m<$countmodule;$m++) 
                          {
                
              //  echo $module[$m];
                             
                          if($module[$m]==$data->name) 
                          {
                  
                        ?>
                             
                <option value="<?php echo $data->name; ?>" selected> <?php echo $data->name; ?> </option>
               
                             <?php
                            $matchcase=$data->name;
                              
                          } 
                          }
                             if($matchcase!=$data->name)
                             {
                             ?>
                             <option value="<?php echo $data->name; ?>"> <?php echo $data->name; ?> </option>
                             <?php
                             }

             
          

                    } ?>
                                  
                  </select>
                </div>

            </div>

              <input type="submit" name="submit" class="btn-large" value="Submit">

            </form>
          </div>

    		</div>
    	</div>
    </div>

    <!--== BOTTOM FLOAT ICON ==-->
     
 
    <!--======== SCRIPT FILES =========-->
     <?php $this->view('admin/layout/footer');?>
     

</body>
</html>