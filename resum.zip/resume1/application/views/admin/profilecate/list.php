<!DOCTYPE html>
<html>
<head>
	<title></title>
    <!--== META TAGS ==-->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!--== FAV ICON ==-->
    <link rel="shortcut icon" href="images/fav.ico">

    <!-- GOOGLE FONTS -->
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:400,600,700" rel="stylesheet">

    <!-- FONT-AWESOME ICON CSS -->
     <link rel="stylesheet" href="<?php echo base_url();?>/media/admin/css/font-awesome.min.css">

    <!--== ALL CSS FILES ==-->
    <link rel="stylesheet" href="<?php echo base_url();?>/media/admin/css/style.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/media/admin/css/mob.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/media/admin/css/bootstrap.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/media/admin/css/materialize.css" />
<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
</head>
<body>
	<!--== MAIN CONTRAINER ==-->
        <?php $this->view('admin/layout/header');?>

    <!--== BODY CONTNAINER ==-->

    <div class="container-fluid sb2">
    	<div class="row">
    		<div class="sb2-1">
    			<!--== LEFT MENU ==-->
                  <?php $this->view('admin/layout/left-menu');?>
    		</div>

    		<div class="sb2-2">
    			<div class="sb2-2-2">
    				<ul>
    					<li>
    						<a href="#"><i class="fa fa-home" aria-hidden="true"></i> Home</a>
    					</li>
    					<li class="active-bre"><a href="#">Slider</a></li>
    				</ul>
    			</div>

    			<div class="sb2-2-1">
    				<div class="inn-title">
    					<h4>All Sliders</h4>
    					<?php echo $this->session->flashdata('message'); ?>
    				</div>
    				<div class="bor">
    					<table class="table" id="example">
    						<thead>
    							<tr>
    								<th>#</th>
    								<th>Image</th>
    								<th>Categ</th>
    								<th>Edit</th>
    								<th>Delete</th>
    							</tr>
    						</thead>

    						<tbody>
    				<?php $i=0; 
                    foreach($PROFILEDATA as $data)
                    { $i++; 

				     ?>

				                <tr bgcolor="#FFFFFF">
				                	<td><?php echo $i; ?></td>
				                	<td><img src="<?php echo base_url(); ?>/media/uploads/profile/<?php echo $data->image; ?>" width="150" height="auto"/></td>
				                	<td><?php echo $data->cate_name; ?></td>
                                    
				                	<!-- //--edit -->
				                	<td width="28%" valign="top" align="center" class="sb2-2-1-edit">
                                        <a href="<?php echo base_url('profile_cate/edit/'.$data->id); ?>"><i class="fa fa-pencil-square-o"></i></a>
                                    </td>
				                	<!-- --delete -->
				                	<td class="sb2-2-1-edit">
				                		<a href="<?php echo base_url('profile_cate/delete/'.$data->id); ?>" onclick="return confirm('are you sure do you want to delete this record')"><i class="fa fa-trash"></i></a>
				                	</td>
				                </tr>
				                <?php } ?> 
    						</tbody>
    					</table>
    				</div>

    			</div>
    		</div>

    	</div>
    </div>
    <!--== BOTTOM FLOAT ICON ==-->
     
 
    <!--======== SCRIPT FILES =========-->
     <?php $this->view('admin/layout/footer');?>
     
<script>
 	$(document).ready(function() {
    $('#example').DataTable( {
       
    } );
} );
</script>
</body>
</html>