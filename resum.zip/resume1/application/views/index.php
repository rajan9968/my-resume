<?php

$EDITDATA =$this->crud->fetchdatabyid('1','resume1_tbl_profile'); 


?>

<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
  

<!-- Mirrored from frenify.net/envato/frenify/html/deeebo/2/index-light.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 16 Apr 2022 09:36:58 GMT -->
<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta name="description" content="Deebo">
<meta name="author" content="Frenify">

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<title>Resume</title>

<!-- Google Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com/" />
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin />
<link href="https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap" rel="stylesheet" />
<!-- /Google Fonts -->

<!-- Styles -->
 <link rel="icon" type="image/png" href="<?php echo base_url();?>assets/img/favicon.png">
<link type="text/css" rel="stylesheet" href="asstes/css/base7dd3.css?ver=4" />
<link type="text/css" rel="stylesheet" href="asstes/css/magnific7dd3.css?ver=4" />
<link type="text/css" rel="stylesheet" href="asstes/css/animated-headlines7dd3.css?ver=4" />
<link type="text/css" rel="stylesheet" href="asstes/css/style7dd3.css?ver=4" />
<!--[if lt IE 9]> <script type="text/javascript" src="js/modernizr.custom.js"></script> <![endif]-->
<!-- /Styles -->

</head>

<body class="light">

<div class="deebo_fn_main">
	
	<!-- Light/Dark Switcher -->
	
	<!-- /Light/Dark Switcher -->
	
	<!-- Overlay -->
	<div class="right_bar_overlay"></div>
	<!--/ Overlay -->

	<!-- MODALBOX -->
	<div class="deebo_fn_modalbox">
		<a class="extra_closer" href="#"></a>
		<div class="box_inner">
			<a class="closer" href="#"><span></span></a>
			<div class="modal_content">

				<div class="modal_in">
					<!-- Content comes from JS -->
				</div>

				<div class="fn__nav" data-from="" data-index="">
					<a href="#" class="prev">
						<span class="text">Prev</span>
						<span class="arrow_wrapper"><span class="arrow"></span></span>
					</a>
					<a href="#" class="next">
						<span class="text">Next</span>
						<span class="arrow_wrapper"><span class="arrow"></span></span>
					</a>
				</div>
			</div>
		</div>
	</div>
	<!-- /MODALBOX --> 

	<!-- Overlay -->
	<div class="right_bar_overlay"></div>
	<!--/ Overlay -->

	<!-- MODALBOX -->
	<div class="deebo_fn_modalbox">
		<a class="extra_closer" href="#"></a>
		<div class="box_inner">
			<a class="closer" href="#"><span></span></a>
			<div class="modal_content">

				<div class="modal_in">
					<!-- Content comes from JS -->
				</div>

				<div class="fn__nav" data-from="" data-index="">
					<a href="#" class="prev">
						<span class="text">Prev</span>
						<span class="arrow_wrapper"><span class="arrow"></span></span>
					</a>
					<a href="#" class="next">
						<span class="text">Next</span>
						<span class="arrow_wrapper"><span class="arrow"></span></span>
					</a>
				</div>
			</div>
		</div>
	</div>
	<!-- /MODALBOX --> 

	<!-- Modal CV Card -->
	<div class="deebo_fn_cv">

		<!-- CV Inner -->
		<div class="deebo_fn__cv">

			<!-- CV Background -->
			<div class="cv__bg"></div>
			<div class="cv__bg2"></div>
			<!-- /CV Background -->

			<!-- CV Left Side -->
			<div class="cv__header">
				<div class="in">
					<div class="avatar">
						<img src="<?php echo base_url();?>/media/uploads/profile/<?php echo $EDITDATA[0]->image;  ?>" alt="">
					</div>
					<h3><span><?php echo $EDITDATA[0]->name; ?></span></h3>
					<p class="quote">I'm a passionate web developer. I assuer that if given a chance to me to work under your kind control, i shall prove my self best up to your expection. <a href="#contact" class="anchor"></a></p>
					<ul class="contact_info">
						<li>
							<span class="icon"><img src="asstes/svg/location.svg" alt="" class="fn__svg"></span>
							<p><?php echo $EDITDATA[0]->address; ?></p>
						</li>
						<li>
							<span class="icon"><img src="asstes/svg/call.svg" alt="" class="fn__svg"></span>
							<p><?php echo $EDITDATA[0]->mobile; ?></p>
						</li>
						<li>
							<span class="icon"><img src="asstes/svg/message.svg" alt="" class="fn__svg"></span>
							<p><a href="https://frenify.net/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="dcbdb8bdb183b1b5b0b2b9ae9cb9a4bdb1acb0b9f2bfb3b1"><?php echo $EDITDATA[0]->email; ?></a></p>
						</li>
					</ul>
				
				</div>
			</div>
			<!-- /CV Left Side -->

			<!-- /CV Content Side -->
			<div class="cv__content">
				
				<section id="hero-header" class="section_header">
					<div class="content">
						<div class="left_hero_header">
							<div class="circle">
								<div class="bg_img" data-bg-img="<?php echo base_url();?>/media/uploads/profile/<?php echo $EDITDATA[0]->image; ?>"></div>
								<img src="<?php echo base_url();?>/media/uploads/profile/<?php echo $EDITDATA[0]->image; ?>" alt="">
								<div class="circle_holder_blue"><span></span></div>
								<div class="circle_holder_orange"><span></span></div>
								<div class="lines">
									<span></span>
									<span></span>
									<span></span>
								</div>
							</div>
						</div>
						<div class="right_hero_header">
							<div class="my_self">
								<h4>Hello! I'm a</h4>
								<h2>
									<!-- It is animation title. You can change animation variation by changing extra class to one of next classes: zoom, rotate-1, letters type, letters rotate-2, loading-bar, slide, clip, letters rotate-3, letters scale, push. cd-headline class can not be removed.  -->
									<span class="cd-headline clip">
										<span class="cd-words-wrapper">
										  <b class="is-visible">Developer</b>
										  <b>Developer</b>
										  
										</span>
									</span>
								</h2>
							</div>
						</div>
					</div>
				</section>


				<!-- CV: Biography Section -->
				<section id="cv_biography">
					<div class="section_title">
						<h3>Biography</h3>
					</div>
					<p>I'm a Web Developer .I code and create web elements for amazing people around the world. I like work with new people. New people are new experiences.</p>
					<div class="fn_cs_info_items">
						<ul>
							<li><p>Name: <span>Rajan Sharma</span></p></li>
							<li><p>Birthday: <span>November 03, 2002</span></p></li>
							<li><p>Languages: <span>English,Hindi</span></p></li>
							<li><p>Age: <span>19 Years</span></p></li>
							<li><p>Nationality: <span>Indain</span></p></li>
							<li><p>Adress: <span>Badle, Delhi</span></p></li>
							
							<li><p>Phone: <span><a href="tel:8285180580">+91 8285180580</a></span></p></li>							
							<li><p>Email: <span><a href="https://frenify.net/cdn-cgi/l/email-protection#0f69636e6d7b6a6e624f68626e6663216c6062"><span class="__cf_email__" data-cfemail="dfb9b3bebdabbabeb29fb8b2beb6b3f1bcb0b2">ra580jan@gmail.com</span></a></span></p></li>
						</ul>
					</div>
				</section>
				<!-- /CV: Biography Section -->


				<!-- CV: Education Section -->
				<section id="cv_education">
					<div class="section_title">
						<h3>Education</h3>
					</div>
					<div class="fn_cs_boxed_list">
						<ul>
							<li>
								<div class="item">
									<div class="item_top">
										<h5>University Delhi</h5>
										<span></span>
									</div>
									<h3>Bachelor of Arts</h3>
									
								</div>
							</li>
							<li>
								<div class="item">
									<div class="item_top">
										<h5>From CBSE</h5>
										
									</div>
									<h3>10th & 12th </h3>
									
								</div>
							</li>
							
						</ul>
					</div>
				</section>
				<!-- /CV: Education Section -->


				<!-- CV: Experience Section -->
				<section id="cv_experience">
					<div class="section_title">
						<h3>Experience</h3>
					</div>
					<div class="fn_cs_boxed_list">
						<ul>
							<li>
								<div class="item">
									<div class="item_top">
										<h5>3 Months Internship</h5>
										<span></span>
									</div>
									<h3></h3>
									<p> </p>
								</div>
							</li>
							
							
						</ul>
					</div>
				</section>
				<!-- /CV: Experience Section -->


				<!-- CV: Skills Section -->
				<section id="cv_skills">
					<div class="section_title">
						<h3>Professionality</h3>
					</div>
					<div class="fn_cs_progress_bar">

						<div class="progress_item" data-value="95">
							<div class="item_in">
								<h3 class="progress_title">HTML5 &amp; CSS</h3>
								<span class="progress_percent"></span>
								<div class="progress_bg"></div>
							</div>
						</div>


						<div class="progress_item" data-value="90">
							<div class="item_in">
								<h3 class="progress_title">Bootstrap</h3>
								<span class="progress_percent"></span>
								<div class="progress_bg"></div>
							</div>
						</div>

						

						<div class="progress_item" data-value="92">
							<div class="item_in">
								<h3 class="progress_title">Php</h3>
								<span class="progress_percent"></span>
								<div class="progress_bg"></div>
							</div>
						</div>

						<div class="progress_item" data-value="95">
							<div class="item_in">
								<h3 class="progress_title">Ajax & Json</h3>
								<span class="progress_percent"></span>
								<div class="progress_bg"></div>
							</div>
						</div>


						<div class="progress_item" data-value="90">
							<div class="item_in">
								<h3 class="progress_title">Codeiginter</h3>
								<span class="progress_percent"></span>
								<div class="progress_bg"></div>
							</div>
						</div>

						<div class="progress_item" data-value="55">
							<div class="item_in">
								<h3 class="progress_title">Javascript</h3>
								<span class="progress_percent"></span>
								<div class="progress_bg"></div>
							</div>
						</div>

						<div class="progress_item" data-value="55">
							<div class="item_in">
								<h3 class="progress_title">Jquery</h3>
								<span class="progress_percent"></span>
								<div class="progress_bg"></div>
							</div>
						</div>
						

						<div class="progress_item" data-value="50">
							<div class="item_in">
								<h3 class="progress_title">WordPress</h3>
								<span class="progress_percent"></span>
								<div class="progress_bg"></div>
							</div>
						</div>


						<div class="progress_item">
							<div class="item_in">
								<h3 class="progress_title"><a href="portfolio.pdf" download>Download CV</a></h3>								
								<div class="progress_bg"></div>
							</div>
						</div>


					</div>
				</section>
				<!-- /CV: Skills Section -->


				<!-- CV: Services Section -->
				
				<!-- /CV: Services Section -->
				
				
				<!-- CV: Portfolio Section-->
				<section id="cv_portfolio">
					<div class="section_title">
						<h3>Projects</h3>
					</div>
					
					<!-- Portfolio Shortcode -->
					<div class="fn_cs_portfolio">
					
						<!-- Portfolio Filter -->
						<div class="portfolio_filter">
							<ul>
								<li><a href="#" class="current" data-filter="*"></a></li>
								
							</ul>
						</div>
						<!-- /Portfolio Filter -->
						
						
						<!-- Portfolio List -->
						<div class="portfolio_list">
							<ul class="gallery_zoom grid">

									<li class="vimeo grid-item">
									<div class="inner">
										<div class="entry">
											<a class="" target="_blank" href="https://web-services.co.in/php-projects/rajan/reobiz/">
												<img src="asstes/img/thumb/42-34.jpg" alt="" />
												<div class="main" data-bg-img="asstes/img/portfolio/4.png"></div>
												<!-- <div class="mobile_title">
													<h3>Ave Bottle</h3>
													<span>Vimeo</span>
												</div> -->
											</a>
										</div>
									</div>
								</li>

								
								
								<li class="vimeo grid-item">
									<div class="inner">
										<div class="entry">
											<a class="" target="_blank" href="http://hamptonfirealarm.co.in/">
												<img src="asstes/img/thumb/42-34.jpg" alt="" />
												<div class="main" data-bg-img="asstes/img/portfolio/2.png"></div>
												<!-- <div class="mobile_title">
													<h3>Ave Bottle</h3>
													<span>Vimeo</span>
												</div> -->
											</a>
										</div>
									</div>
								</li>
								<li class="vimeo grid-item">
									<div class="inner">
										<div class="entry">
											<a class="" target="_blank" href="https://vppackagingindustries.com/">
												<img src="asstes/img/thumb/42-34.jpg" alt="" />
												<div class="main" data-bg-img="asstes/img/portfolio/3.png"></div>
												<!-- <div class="mobile_title">
													<h3>Ave Bottle</h3>
													<span>Vimeo</span>
												</div> -->
											</a>
										</div>
									</div>
								</li>
							

								<li class="vimeo grid-item">
									<div class="inner">
										<div class="entry">
											<a class="" target="_blank" href="https://web-services.co.in/codeigniter-projects/rajan/techmax/">
												<img src="asstes/img/thumb/42-34.jpg" alt="" />
												<div class="main" data-bg-img="asstes/img/portfolio/5.png"></div>
												<!-- <div class="mobile_title">
													<h3>Ave Bottle</h3>
													<span>Vimeo</span>
												</div> -->
											</a>
										</div>
									</div>
								</li>

								<li class="youtube grid-item">
									<div class="inner">
										<div class="entry">
											<a class="" target="_blank" href="https://australia.roundworldimmigration.com/">
												<img src="asstes/img/thumb/42-56.jpg" alt="" />
												<div class="main" data-bg-img="asstes/img/portfolio/1.png"></div>
												<!-- <div class="mobile_title">
													<h3>Mockup Shape</h3>
													<span>Youtube</span>
												</div> -->
											</a>
										</div>
									</div>
								</li>

								<li class="vimeo grid-item">
									<div class="inner">
										<div class="entry">
											<a class="" target="_blank" href="https://web-services.co.in/codeigniter-projects/rajan/medd/">
												<img src="asstes/img/thumb/42-34.jpg" alt="" />
												<div class="main" data-bg-img="asstes/img/portfolio/6.png"></div>
												<!-- <div class="mobile_title">
													<h3>Ave Bottle</h3>
													<span>Vimeo</span>
												</div> -->
											</a>
										</div>
									</div>
								</li>

								<li class="vimeo grid-item">
									<div class="inner">
										<div class="entry">
											<a class="" target="_blank" href="https://web-services.co.in/codeigniter-projects/rajan/medic/">
												<img src="asstes/img/thumb/42-34.jpg" alt="" />
												<div class="main" data-bg-img="asstes/img/portfolio/7.png"></div>
											<!-- 	<div class="mobile_title">
													<h3>Ave Bottle</h3>
													<span>Vimeo</span>
												</div> -->
											</a>
										</div>
									</div>
								</li>
							
							
							</ul>
						</div>
						<!-- /Portfolio List -->
						
					</div>
					<!-- /Portfolio Shortcode -->
					
				</section>
				<!-- /CV: Portfolio Section-->

				<!-- CV: Testimonials -->
				
				<!-- /CV: Testimonials -->
				
				
				<!-- CV: Clients Section -->
				
				<!-- /CV: Clients Section -->
				
				
				<!-- CV: News Section -->
				
				<!-- /CV: News Section -->
				
				
				<!-- CV: Contact Section -->
				<section id="contact" class="section_contact">
					<div class="section_title">
						<h3>Contact Me</h3>
					</div>
					<form class="contact_form" action="" method="post" autocomplete="off">

						<!--
							Don't remove below code in avoid to work contact form properly.
							You can chance dat-success value with your one. It will be used when user will try to contact via contact form and will get success message.
						-->
						<div class="success" data-success="Your message has been received, we will contact you soon."></div>
						<div class="empty_notice"><span>Please Fill Required Fields!</span></div>
						<!-- -->

						<div class="items_wrap">
							<div class="items">
								<div class="item half">
									<div class="input_wrapper">
										<input id="name" name="name" type="text" placeholder="Name *" />
									</div>
								</div>
								<div class="item half">
									<div class="input_wrapper">
										<input id="email" name="email" type="email" placeholder="Email *" />
									</div>
								</div>
								<div class="item">
									<div class="input_wrapper">
										<input id="phone" name="mobile" type="text" placeholder="Phone" />
									</div>
								</div>
								<div class="item">
									<div class="input_wrapper">
										<textarea name="message" id="message" placeholder="Message"></textarea>
									</div>
								</div>
								<div class="item">
									<button style="border: aliceblue;
    padding: 17px;
    width: 89%;
    display: flex;
    justify-content: center;
    font-size: 15px;
    color: #3452ff;
    margin-left: 5%;
    border-radius: 6%;
    cursor: pointer;
}" type="submit" name="submit">Send Messag</button>
								</div>
							</div>
						</div>
					</form>
				</section>
				<!-- CV: Contact Section -->


			</div>
			<!-- /CV Content Side -->

		</div>
		<!-- CV Inner -->
	</div>
	<!-- /Modal CV Card -->

	

</div>

<!-- Scripts -->
<script data-cfasync="false" src="../../../../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="text/javascript" src="asstes/js/jquery7dd3.js?ver=4"></script>
<script type="text/javascript" src="asstes/js/isotope.js"></script>
<script type="text/javascript" src="asstes/js/magnific.js"></script>
<script type="text/javascript" src="asstes/js/animated-headlines7dd3.js?ver=4"></script>
<script type="text/javascript" src="asstes/js/waypoints7dd3.js?ver=4"></script>
<!--[if lt IE 10]> <script type="text/javascript" src="js/ie8.js"></script> <![endif]-->
<script type="text/javascript" src="asstes/js/init7dd3.js?ver=4"></script>
<!-- /Scripts -->

</body>

<!-- Mirrored from frenify.net/envato/frenify/html/deeebo/2/index-light.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 16 Apr 2022 09:37:27 GMT -->
</html>